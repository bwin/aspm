# Test app

Demostrates a simple configuration that uses node-pre-gyp.